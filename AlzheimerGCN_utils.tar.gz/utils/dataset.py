"""PyTorch Dataset for multimodal Alzheimer’s disease classification.

This module defines the `AlzheimerDataset`, which loads:
  - DTI-based FA brain networks (90x90 adjacency matrices),
  - ROIS node features (90-dimensional vectors),
  - Clinical feature vectors,
  - Graph labels (AD=0, NC=1).

It converts the adjacency matrices and node features into PyTorch Geometric
`Data` objects for consumption by the GCN-based DTI branch, while returning
clinical features as separate tensors.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset
from torch_geometric.data import Data
import yaml

from .graph_utils import adjacency_to_edge_index as _adjacency_to_edge_index_core


def load_config(config_path: Path) -> Dict:
    """Load YAML configuration file.

    Args:
        config_path: Path to the `config.yaml` file.

    Returns:
        Parsed configuration dictionary.
    """
    try:
        with config_path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except OSError as exc:
        raise RuntimeError(f"Failed to read config file at '{config_path}'.") from exc
    except yaml.YAMLError as exc:
        raise RuntimeError(f"Failed to parse YAML config at '{config_path}'.") from exc


def adjacency_to_edge_index(adj_matrix: np.ndarray) -> Tuple[Tensor, Tensor]:
    """Convert a dense adjacency matrix to PyG edge_index/edge_attr.

    This is a thin wrapper around `utils.graph_utils.adjacency_to_edge_index`
    provided here for convenience, matching the specification.

    Args:
        adj_matrix: Square numpy array of shape (N, N).

    Returns:
        edge_index: LongTensor of shape (2, E).
        edge_attr: FloatTensor of shape (E,).
    """
    return _adjacency_to_edge_index_core(adj_matrix)


class AlzheimerDataset(Dataset):
    """PyTorch Dataset for Alzheimer’s disease multimodal data.

    Each item consists of:
      - `graph_data`: PyG `Data` object with fields:
            x: (90, F) node feature matrix
            edge_index: (2, E) graph connectivity
            edge_attr: (E,) edge weights (FA values)
            y: (1,) graph label (0 for AD, 1 for NC)
      - `clinical_tensor`: (6,) clinical feature vector
      - `label`: scalar tensor with the same value as `graph_data.y`
    """

    def __init__(
        self,
        subject_ids: Optional[List[str]],
        config: Dict,
        split: str = "train",
    ) -> None:
        """Initialize the AlzheimerDataset.

        Args:
            subject_ids: Optional list of subject IDs to include. If `None`,
                IDs are loaded from the corresponding split file in
                `dataset.splits_dir` based on the `split` argument.
            config: Parsed configuration dictionary (from `config.yaml`).
            split: Dataset split name, either `"train"` or `"test"`.
        """
        super().__init__()

        if split not in {"train", "test"}:
            raise ValueError(f"Unsupported split '{split}'. Use 'train' or 'test'.")

        dataset_cfg = config.get("dataset", {})
        clinical_csv = Path(dataset_cfg.get("clinical_csv", ""))
        networks_dir = Path(dataset_cfg.get("networks_dir", ""))
        node_features_dir = Path(dataset_cfg.get("node_features_dir", ""))
        splits_dir = Path(dataset_cfg.get("splits_dir", ""))

        if not clinical_csv:
            raise RuntimeError("Missing 'dataset.clinical_csv' in configuration.")
        if not networks_dir:
            raise RuntimeError("Missing 'dataset.networks_dir' in configuration.")
        if not node_features_dir:
            raise RuntimeError("Missing 'dataset.node_features_dir' in configuration.")
        if not splits_dir:
            raise RuntimeError("Missing 'dataset.splits_dir' in configuration.")

        self.networks_dir: Path = networks_dir
        self.node_features_dir: Path = node_features_dir
        self.splits_dir: Path = splits_dir
        self.clinical_dir: Path = clinical_csv.parent

        # Load subject IDs from split files if not provided.
        if subject_ids is None:
            split_file = (
                self.splits_dir / "train_ids.txt"
                if split == "train"
                else self.splits_dir / "test_ids.txt"
            )
            try:
                raw_ids = split_file.read_text(encoding="utf-8").strip().splitlines()
            except OSError as exc:
                raise RuntimeError(
                    f"Failed to read subject IDs from '{split_file}'."
                ) from exc
            self.subject_ids: List[str] = [sid.strip() for sid in raw_ids if sid.strip()]
        else:
            self.subject_ids = [str(sid) for sid in subject_ids]

        if not self.subject_ids:
            raise RuntimeError("No subject IDs provided or loaded from split files.")

        # Load labels from labels.csv
        labels_csv = self.networks_dir / "labels.csv"
        try:
            labels_df = torch.from_numpy  # type: ignore[assignment]
        except Exception:
            # Dummy branch to avoid linter, real loading below.
            pass

        try:
            import pandas as pd  # local import to avoid global dependency issues

            labels_df_pd = pd.read_csv(labels_csv)
        except OSError as exc:
            raise RuntimeError(f"Failed to read labels.csv at '{labels_csv}'.") from exc

        if not {"SubjectID", "Label"}.issubset(labels_df_pd.columns):
            raise RuntimeError(
                "labels.csv must contain 'SubjectID' and 'Label' columns."
            )

        label_map: Dict[str, int] = {
            str(row["SubjectID"]): int(row["Label"])
            for _, row in labels_df_pd.iterrows()
        }

        # Load clinical features and subject order.
        clinical_features_path = self.clinical_dir / "clinical_features.npy"
        clinical_subject_ids_path = self.clinical_dir / "clinical_subject_ids.npy"

        try:
            clinical_features = np.load(clinical_features_path, allow_pickle=False)
            clinical_subject_ids = np.load(
                clinical_subject_ids_path, allow_pickle=True
            ).astype(str)
        except OSError as exc:
            raise RuntimeError(
                "Failed to load clinical features or subject IDs. "
                f"Expected at '{clinical_features_path}' and '{clinical_subject_ids_path}'."
            ) from exc

        clinical_index: Dict[str, int] = {
            sid: idx for idx, sid in enumerate(clinical_subject_ids)
        }

        self.graphs: List[Data] = []
        self.clinical_tensors: List[Tensor] = []
        self.labels: List[int] = []

        # Preload all subjects into memory for simplicity.
        for sid in self.subject_ids:
            if sid not in label_map:
                raise RuntimeError(
                    f"Subject ID '{sid}' not found in labels.csv; "
                    "ensure DTI preprocessing and label mapping are complete."
                )
            if sid not in clinical_index:
                raise RuntimeError(
                    f"Subject ID '{sid}' does not have clinical features; "
                    "ensure prepare_clinical.py has been run."
                )

            network_path = self.networks_dir / f"{sid}_FA_network.npy"
            node_feat_path = self.node_features_dir / f"{sid}_ROIS.npy"

            try:
                adj = np.load(network_path, allow_pickle=False)
            except OSError as exc:
                raise RuntimeError(
                    f"Failed to load adjacency matrix for subject '{sid}' "
                    f"from '{network_path}'."
                ) from exc

            try:
                node_features = np.load(node_feat_path, allow_pickle=False)
            except OSError as exc:
                raise RuntimeError(
                    f"Failed to load node features for subject '{sid}' "
                    f"from '{node_feat_path}'."
                ) from exc

            # Ensure node features have shape (N, F); here N=90, F=1 or F=90.
            if node_features.ndim == 1:
                node_features = node_features[:, None]

            edge_index, edge_attr = adjacency_to_edge_index(adj)

            label_val = int(label_map[sid])
            y = torch.tensor([label_val], dtype=torch.long)

            graph = Data(
                x=torch.from_numpy(node_features.astype(np.float32)),
                edge_index=edge_index,
                edge_attr=edge_attr,
                y=y,
            )
            self.graphs.append(graph)

            clin_vec = clinical_features[clinical_index[sid]]
            self.clinical_tensors.append(
                torch.from_numpy(clin_vec.astype(np.float32))
            )
            self.labels.append(label_val)

    def __len__(self) -> int:
        """Return the number of subjects in the dataset."""
        return len(self.graphs)

    def __getitem__(self, idx: int) -> Tuple[Data, Tensor, Tensor]:
        """Return a single sample from the dataset.

        Args:
            idx: Integer index of the sample.

        Returns:
            A tuple `(graph_data, clinical_tensor, label)` where:
                - `graph_data` is a PyG `Data` object,
                - `clinical_tensor` is a float tensor of shape (6,),
                - `label` is a long tensor scalar (0 or 1).
        """
        graph_data = self.graphs[idx]
        clinical_tensor = self.clinical_tensors[idx]
        label = torch.tensor(self.labels[idx], dtype=torch.long)
        return graph_data, clinical_tensor, label

