"""Clinical data branch: small MLP to produce a 16-dim embedding.

Architecture:
    Linear(6 → 32) → BatchNorm → ReLU → Dropout(0.3)
    Linear(32 → 16) → ReLU

The input is a 6-dimensional clinical feature vector per subject:
    [AGE, GENDER, MMSE, CDRSB, APOE4, PTEDUCAT]
"""

from __future__ import annotations

from typing import Dict

import torch
from torch import Tensor, nn


class ClinicalBranch(nn.Module):
    """Multilayer perceptron for clinical feature embeddings."""

    def __init__(self, config: Dict) -> None:
        """Initialize the ClinicalBranch from configuration.

        Args:
            config: Parsed configuration dictionary (from `config.yaml`).
                Expected keys under `model`:
                    - clinical_input_dim
                    - clinical_hidden_dim
                    - clinical_embedding_dim
        """
        super().__init__()
        model_cfg = config.get("model", {})

        in_dim: int = int(model_cfg.get("clinical_input_dim", 6))
        hidden_dim: int = int(model_cfg.get("clinical_hidden_dim", 32))
        emb_dim: int = int(model_cfg.get("clinical_embedding_dim", 16))

        self.net: nn.Sequential = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.3),
            nn.Linear(hidden_dim, emb_dim),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass for the clinical branch MLP.

        Args:
            x: Clinical feature tensor of shape (batch_size, 6).

        Returns:
            Clinical embedding tensor of shape (batch_size, 16).
        """
        return self.net(x)

