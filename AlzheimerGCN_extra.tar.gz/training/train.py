from __future__ import annotations

import argparse
import numpy as np
import torch
from torch import nn
from torch.optim import Adam
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm
from torch_geometric.data import Data, Batch

from models.multimodal_model import MultiModalADModel


def convert_to_graph_batch(X):
    graphs = []
    for i in range(X.size(0)):
        adj = X[i]

        x = adj  # node features (90 x 90)

        edge_index = (adj > 0).nonzero(as_tuple=False).t().contiguous()

        graph = Data(x=x, edge_index=edge_index)
        graphs.append(graph)

    return Batch.from_data_list(graphs)


def train(config_path: str) -> None:
    try:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # =========================
        # LOAD DATA
        # =========================
        X_train = np.load("data/processed/dataset/X_train.npy")
        X_test = np.load("data/processed/dataset/X_test.npy")
        y_train = np.load("data/processed/dataset/y_train.npy")
        y_test = np.load("data/processed/dataset/y_test.npy")

        X_train = torch.tensor(X_train, dtype=torch.float32)
        X_test = torch.tensor(X_test, dtype=torch.float32)
        y_train = torch.tensor(y_train, dtype=torch.long)
        y_test = torch.tensor(y_test, dtype=torch.long)

        train_dataset = TensorDataset(X_train, y_train)
        test_dataset = TensorDataset(X_test, y_test)

        # ✅ FIX: drop_last=True to avoid BatchNorm crash
        train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True, drop_last=True)
        test_loader = DataLoader(test_dataset, batch_size=8, shuffle=False, drop_last=True)

        # =========================
        # MODEL
        # =========================
        model = MultiModalADModel({}).to(device)

        loss_fn = nn.CrossEntropyLoss()
        optimizer = Adam(model.parameters(), lr=0.001)

        num_epochs = 30

        print("=== Training Started ===")

        for epoch in range(1, num_epochs + 1):
            model.train()
            correct = 0
            total = 0

            for X, y in tqdm(train_loader, desc=f"Epoch {epoch}"):
                X = X.to(device)
                y = y.to(device)

                optimizer.zero_grad()

                graph_batch = convert_to_graph_batch(X).to(device)

                # ✅ FIXED clinical input
                clinical_dummy = torch.zeros((X.size(0), 6)).to(device)

                outputs = model(graph_batch, clinical_dummy)

                loss = loss_fn(outputs, y)
                loss.backward()
                optimizer.step()

                preds = torch.argmax(outputs, dim=1)
                correct += (preds == y).sum().item()
                total += y.size(0)

            train_acc = correct / total

            # =========================
            # VALIDATION
            # =========================
            model.eval()
            correct = 0
            total = 0

            with torch.no_grad():
                for X, y in test_loader:
                    X = X.to(device)
                    y = y.to(device)

                    graph_batch = convert_to_graph_batch(X).to(device)

                    clinical_dummy = torch.zeros((X.size(0), 6)).to(device)

                    outputs = model(graph_batch, clinical_dummy)

                    preds = torch.argmax(outputs, dim=1)
                    correct += (preds == y).sum().item()
                    total += y.size(0)

            val_acc = correct / total

            print(f"Epoch {epoch} | Train Acc: {train_acc:.4f} | Test Acc: {val_acc:.4f}")

        print("=== Training Complete ===")

    except Exception as exc:
        raise RuntimeError("Training failed.") from exc


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/config.yaml")
    args = parser.parse_args()

    train(args.config)